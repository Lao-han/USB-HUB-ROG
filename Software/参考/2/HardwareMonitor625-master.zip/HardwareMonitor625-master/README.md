# HardwareMonitor625
