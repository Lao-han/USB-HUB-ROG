#pragma once

#include "resource.h"
#include "shellapi.h"
